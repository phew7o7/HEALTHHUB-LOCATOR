const express = require('express');
const Papa = require('papaparse');
const cors = require('cors');
const path = require('path'); 
 // Import the path module
 const fs = require('fs');

const app = express();
const PORT = 3001;

app.use(cors());

// Serve static files (HTML, JS, CSS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// CSV file path
const csvFilePath = path.join(__dirname, 'Hospital_directory.csv');



app.get('/search', (req, res) => {
    const state = req.query.state;
    const district = req.query.district;
    const city = req.query.city;

    

    // Read and parse the CSV file
    fs.readFile(csvFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading CSV file:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }

        Papa.parse(data, {
            header: true,
            complete: function (results) {
                try {
                    // Search for matching rows
                    const matchingRows = results.data.filter(row => row.State === state && row.District === district);

                    console.log("===========>",results,state,district,city,)
                    res.json(matchingRows);
                } catch (error) {
                    console.error('Error parsing CSV file:', error);
                    res.status(500).json({ error: 'Internal Server Error' });
                }
            },
            error: function (error) {
                console.error('Error parsing CSV file:', error);
                res.status(500).json({ error: 'Internal Server Error' });
            }
        });
    });
});


// Listen for incoming connections
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});

// Serve the results page
app.get('/results', (req, res) => {
    res.sendFile(path.join(__dirname, 'results.html'));
});

// Serve the homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'Hospital.html'));
});
